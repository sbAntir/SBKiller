import toKill

sb = input("Enter a name who you want to kill: ")
status = bool(input("Are you sure that you want to kill? Enter 1 for true or 0 for false: "))
if sb:
    if status:
        print(toKill.killSb(sb))
    else:
        status = False
        print(toKill.killSb(sb, status))
else:
    s = ""
    print(toKill.killSb(s, status = False))
