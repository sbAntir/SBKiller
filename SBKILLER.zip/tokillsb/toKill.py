def killSb(sb, status = True):
    if sb:
        if status:
            toPrint = "Killed " + sb
            while status:
                return toPrint
                status = False
        else:
            toPrint = "Object not found"
            return toPrint
    else:
        toPrint = "Name is invalid"
        return toPrint
